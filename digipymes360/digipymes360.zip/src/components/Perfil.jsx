import { useEffect, useState } from "react";
import gato_naranja from "../img/gato_naranja.jpg";

export default function Perfil() {
    const [userData, setUserData] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");

    useEffect(() => {
        try {
            const storedUser = localStorage.getItem("UserData");
            if (!storedUser) {
                console.warn("No hay datos de usuario en localStorage");
                return;
            }

            const parsedUser = JSON.parse(storedUser);
            if (!parsedUser || parsedUser.id_usuario == null) {
                console.error("UserData inválido:", parsedUser);
                return;
            }

            setUserData(parsedUser);
        } catch (err) {
            console.error("Error al leer UserData:", err);
        }
    }, []);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setUserData((prev) => ({
            ...prev,
            [id === "addressTextInput" ? "direccion" : id === "telefonoTextInput" ? "telefono" : id === "emailTextInput" ? "email" : id]: value,
        }));
    };

    const handleUpdateAll = async () => {
    try {
        await handleUpdateCorreo();
        await handleUpdateDireccionTelefono();
        setMessage("Perfil actualizado correctamente");
        setIsEditing(false);
    } catch (err) {
        console.error("Error en handleUpdateAll:", err);
        setMessage("Error al actualizar el perfil.");
    }
};


    const handleUpdateCorreo = async () => {
        if (!userData) return;
        setLoading(true);
        setMessage("");

        try {
            const response = await fetch("http://localhost:8080/api/v2/user/putMail", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    id: userData.id_usuario,
                    nuevo_email: userData.email,
                }),
            });

            if (!response.ok) {
                const text = await response.text();
                console.error("Error HTTP:", response.status, text);
                throw new Error(text || "Error al actualizar el correo.");
            }

            const updatedData = await response.json();
            console.log("Correo actualizado:", updatedData);

            setUserData(updatedData);
            localStorage.setItem("UserData", JSON.stringify(updatedData));
            setMessage("Correo actualizado correctamente");
        } catch (err) {
            console.error("Error en handleUpdateCorreo:", err);
            setMessage("Error al actualizar el correo.");
        } finally {
            setLoading(false);
        }
    };

    const handleUpdateDireccionTelefono = async () => {
        if (!userData) return;
        setLoading(true);
        setMessage("");

        try {
            const response = await fetch("http://localhost:8080/api/v2/user/putAddressPhone", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    id: userData.id_usuario,
                    direccion: userData.direccion,
                    telefono: userData.telefono,
                }),
            });

            if (!response.ok) {
                const text = await response.text();
                console.error("Error HTTP:", response.status, text);
                throw new Error(text || "Error al actualizar dirección/teléfono.");
            }

            const updatedData = await response.json();
            console.log("Dirección/teléfono actualizado:", updatedData);

            setUserData(updatedData);
            localStorage.setItem("UserData", JSON.stringify(updatedData));
            setMessage("Dirección y teléfono actualizados correctamente");
        } catch (err) {
            console.error("Error en handleUpdateDireccionTelefono:", err);
            setMessage("Error al actualizar dirección/teléfono.");
        } finally {
            setLoading(false);
        }
    };

    if (!userData) {
        return <p className="text-center mt-5">Cargando perfil...</p>;
    }

    return (
        <main className="min-h-screen">
            <form className="perfilUsuario" id="perfilUsuarioForm" onSubmit={(e) => e.preventDefault()}>
                <div className="mt-4">
                    <h3 className="textoPerfil">
                        <strong>Perfil de {userData.nombre}</strong>
                    </h3>
                </div>
                <div className="gato_naranja">
                    <img
                        src={gato_naranja}
                        className="gato_naranja2 rounded-circle"
                        alt="imagen de perfil"
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="emailTextInput" className="form-label textForm">
                        Correo
                    </label>
                    <input
                        type="email"
                        id="emailTextInput"
                        className="form-control"
                        value={userData.email || ""}
                        onChange={handleChange}
                        readOnly={!isEditing}
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="addressTextInput" className="form-label textForm">
                        Dirección
                    </label>
                    <input
                        type="text"
                        id="addressTextInput"
                        className="form-control"
                        value={userData.direccion || ""}
                        onChange={handleChange}
                        readOnly={!isEditing}
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="telefonoTextInput" className="form-label textForm">
                        Teléfono
                    </label>
                    <input
                        type="text"
                        id="telefonoTextInput"
                        className="form-control"
                        value={userData.telefono || ""}
                        onChange={handleChange}
                        readOnly={!isEditing}
                    />
                </div>

                {message && (
                    <p className="text-center mt-3">
                        {message}
                    </p>
                )}

                <div className="d-flex justify-content-center mb-4 flex-wrap gap-2">
                    {!isEditing ? (
                        <button
                            type="button"
                            className="btn btn-primary px-5"
                            onClick={() => setIsEditing(true)}
                        >
                            Editar
                        </button>
                    ) : (
                        <button
                            type="button"
                            className="btn btn-success px-5"
                            onClick={handleUpdateAll}
                            disabled={loading}
                        >
                            {loading ? "Actualizando..." : "Actualizar"}
                        </button>
                    )}

                    <button
                        type="button"
                        className="btn btn-danger px-5"
                        onClick={() => {
                            localStorage.setItem("Logged", "false");
                            localStorage.removeItem("UserData");
                            window.location.href = "/login";
                        }}
                    >
                        Cerrar sesión
                    </button>
                </div>
            </form>
        </main>
    );
}
